//
//  DashboardDragRegions.js
//  WidgetPortingAPP
//
//  Created by Niko on 27.04.26.
//

(function () {
    if (window.__dashboardDragRegionsInitialized) return;
    window.__dashboardDragRegionsInitialized = true;

    var pendingDrag = null;
    var activeDrag = null;
    var dragThreshold = 3;
    var sourceRules = [];
    var bundledStylesheetSources = [".draghandle {\n\tbackground-image:url(..\/images\/skin_tall\/tall_draghandle.png);\n\tposition:absolute;\n\twidth:21px;\n\theight:11px;\n\t-apple-dashboard-region: dashboard-region(control rectangle);\n}\n\n.draghandleMask {\n\tbackground-image:url(..\/images\/skin_tall\/tall_dragsection.png);\n\twidth:144px;\n\theight:58px;\t\n\tposition:absolute;\n\tdisplay:none;\n}\n\n.draghandlenewpos {\n\twidth:144px;\n\theight:13px;\n\ttop:6px;\n\tleft:10px;\n\tposition:absolute;\n\tdisplay:none;\n\tz-index:999;\n}\n\n.base {\n\tbackground-image:url(..\/images\/skin_tall\/tall_footer.png);\n\twidth:164px;\n\theight:27px;\n\tposition:absolute;\n}\n\n.processIcon {\n\tposition: absolute;\n\tleft: 20px;\n\theight: 16px;\n\twidth: 16px;\n}\n\n.processName {\n\tposition: absolute;\n\tleft: 40px;\n\ttext-shadow: black 0px 2px 2px;\n\ttext-overflow: ellipsis;\n\twhite-space: nowrap;\n\toverflow: hidden;\n\theight: 13px;\n\twidth: 69px;\n}\n\n.processCPU {\n\ttext-align: right;\n\tposition: absolute;\n\tleft: 105px;\n\ttext-shadow: black 0px 2px 2px;\n\ttext-overflow: ellipsis;\n\twhite-space: nowrap;\n\toverflow: hidden;\n\theight: 13px;\n\twidth: 40px;\n}\n\n.line1 {\n\ttop:12px;\n}\n\n.line2 {\n\ttop:23px;\n}\n\n.line3 {\n\ttop:34px;\n}\n\n.line4 {\n\ttop:45px;\n}\n\n.line5 {\n\ttop:56px;\n}\n\n.line6 {\n\ttop:67px;\n}\n\n.line7 {\n\ttop:78px;\n}\n\n.line8 {\n\ttop:89px;\n}\n\n.sectioncontainer {\n\tposition:absolute;\n\tdisplay:none;\n\twidth:164px;\n\tpadding:0px 8px 0px 8px;\n\toverflow:hidden;\n\tbackground-repeat:repeat-y;\n\tbackground-image:url(..\/images\/skin_tall\/tall_mid_section.png);\n}\n\n.header {\n\tposition:absolute;\n\ttop:0px;\n\tfont: 8.0px 'Lucida Grande';\n\tfont-weight:bold;\n\ttext-transform: uppercase;\n\tletter-spacing: 0.2em;\n\ttext-align:center;\n\twidth:150px;\n}\n\n.divider {\n\tposition:absolute;\n\tdisplay:block;\n\tbackground-image:url(..\/images\/skin_tall\/tall_divider.png), url(..\/images\/skin_tall\/tall_mid_section.png);\n\tbackground-repeat:no-repeat, repeat-y;\n\twidth:164px;\n\tleft:0px;\n\theight:2px;\n\tpadding:4px 0px 4px 0px;\n\tbackground-position:center left, top left;\n\ttop:0px;\n}\n\n.inlinedivider {\n\tposition:absolute;\n\tdisplay:block;\n\tbackground-image:url(..\/images\/skin_tall\/tall_divider.png);\n\tbackground-repeat:no-repeat;\n\twidth:164px;\n\tleft:0px;\n\theight:2px;\n\tpadding:4px 0px 4px 0px;\n\tbackground-position:center left;\n}\n",".draghandle {\n\tbackground-image:url(..\/images\/skin_wide\/wide_draghandle.png);\n\tposition:absolute;\n\twidth:21px;\n\theight:17px;\n\t-apple-dashboard-region: dashboard-region(control rectangle);\n\tright:0px;\n\ttop:2px;\n}\n\n.draghandleMask {\n\tbackground-image:url(..\/images\/skin_wide\/wide_dragsection.png);\n\twidth:77px;\n\theight:110px;\t\n\tposition:absolute;\n\tdisplay:none;\n}\n\n.draghandlenewpos {\n\twidth:13px;\n\theight:109px;\n\ttop:6px;\n\tposition:absolute;\n\tdisplay:none;\n\tz-index:999;\n}\n\n.processIcon {\n\tposition: absolute;\n\tleft: 0px;\n\theight: 16px;\n\twidth: 16px;\n}\n\n.processName {\n\tposition: absolute;\n\tleft: 20px;\n\ttext-shadow: black 0px 2px 2px;\n\ttext-overflow: ellipsis;\n\twhite-space: nowrap;\n\toverflow: hidden;\n\theight: 13px;\n\twidth: 69px;\n}\n\n.processCPU {\n\ttext-align: right;\n\tposition: absolute;\n\tleft: 90px;\n\ttext-shadow: black 0px 2px 2px;\n\ttext-overflow: ellipsis;\n\twhite-space: nowrap;\n\toverflow: hidden;\n\theight: 13px;\n\twidth: 40px;\n}\n\n.line1 {\n\ttop:20px;\n}\n\n.line2 {\n\ttop:31px;\n}\n\n.line3 {\n\ttop:42px;\n}\n\n.line4 {\n\ttop:53px;\n}\n\n.line5 {\n\ttop:64px;\n}\n\n.line6 {\n\ttop:75px;\n}\n\n.line7 {\n\ttop:86px;\n}\n\n.line8 {\n\ttop:97px;\n}\n\n.sectioncontainer {\n\tposition:absolute;\n\tdisplay:none;\n\tbackground-image:url(..\/images\/skin_wide\/wide_mid_section.png);\n\theight:130px;\n\tpadding:0px 0px 0px 0px;\n\toverflow:hidden;\n\tbackground-repeat:repeat-x;\n}\n\n.divider {\n\tposition:absolute;\n\tdisplay:none;\n\tbackground-image:url(..\/images\/skin_wide\/wide_divider.png),url(..\/images\/skin_wide\/wide_mid_section.png);\n\tbackground-repeat:no-repeat, repeat-x;\n\tbackground-position:top center,top left;\n\twidth:2px;\n\theight:130px;\n\ttop:0px;\n\tpadding:0px 5px 0px 5px;\n}\n\n.inlinedivider {\n\tmargin-left:6px;\n\tbackground-image:url(..\/images\/skin_wide\/wide_divider.png);\n\tbackground-repeat:no-repeat;\n\twidth:8px;\n\theight:130px;\n\tfloat:left;\n\tposition:absolute;\t\n}\n\n.header {\n\tposition:absolute;\n\ttop:10px;\n\tfont: 8.0px 'Lucida Grande';\n\tfont-weight:bold;\n\ttext-transform: uppercase;\n\tletter-spacing: 0.2em;\n}",".barbg {\n\tbackground-image:url(.\/images\/common\/bar_horizontal_bg.png);\n\theight:8px;\n\toverflow:hidden;\n}\n\n.verticalbarbg {\n\tbackground-image:url(.\/images\/common\/bar_vertical_bg.png);\n\twidth:8px;\n\toverflow:hidden;\n}\n\ncanvas {\n\tbackground-image:url(.\/images\/common\/graph_bg.png);\n}\n\n.smallcanvas {\n\tbackground-image:url(.\/images\/common\/graph_bg_small.png);\n}\n\n.size {\n\tfont-size:8px;\n}\n\n.label {\n\tcolor: #838383;\n}\n\n.line {\n\tposition:absolute;\n\theight:12px;\n\toverflow:hidden;\n\tleft:0px;\n\tfont:7.5pt \"Lucida Grande\";\n\tfont-weight: bold;\t\t\t\n}\n\n.ellipsis {\n\ttext-overflow: ellipsis;\n\twhite-space: nowrap;\n\toverflow: hidden;\n\tfont:7.5pt \"Lucida Grande\";\n\tfont-weight: bold;\t\t\t\n}\n\n.filternamesel {\n\tbackground-image:url(.\/images\/back\/display_highlight.png);\n\ttext-shadow: rgba(0,0,0,0.6) 0px 1px 0px;\t\n}\n\nselect, input {\n\topacity:0;\n\tz-index:100;\n}\n\n.done {\n\tposition:absolute;\n\theight:17px;\n\twidth:98px;\n\ttop:98px;\n\tleft:136px;\n\tcursor:pointer;\n}\n\n.update {\n\tposition:absolute;\n\tbackground-image:url(.\/images\/back\/button_update.png);\n\theight:17px;\n\twidth:212px;\n\ttop:129px;\n\tleft:22px;\n\tcursor:pointer;\n}\n\n.update:hover {\n\tbackground-image:url(.\/images\/back\/button_update_rollie.png);\n}\n\n.paypal {\n\tposition:absolute;\n\tbackground-image:url(.\/images\/back\/button_donate.png);\n\theight:17px;\n\twidth:98px;\n\ttop:15px;\n\tleft:22px;\n\tcursor:pointer;\n}\n\n.paypal:hover {\n\tbackground-image:url(.\/images\/back\/button_donate_rollie.png);\n}\n\n.iphoneapps {\n\tposition:absolute;\n\tbackground-image:url(.\/images\/back\/button_iphone.png);\n\theight:17px;\n\twidth:98px;\n\ttop:15px;\n\tleft:136px;\n\tcursor:pointer;\n}\n\n.iphoneapps:hover {\n\tbackground-image:url(.\/images\/back\/button_iphone_rollie.png);\n}\n\n#ok {\n\tbackground-image:url(.\/images\/windows\/button_ok.png);\n\theight:24px;\n\twidth:64px;\n\tfloat:left;\n}\n\n#no {\n\tbackground-image:url(.\/images\/windows\/button_no_sml.png);\n\theight:24px;\n\twidth:44px;\n\tfloat:left;\n}\n#yes {\n\tbackground-image:url(.\/images\/windows\/button_yes_sml.png);\n\theight:24px;\n\twidth:44px;\n\tfloat:left;\n}\n#skip {\n\tbackground-image:url(.\/images\/windows\/button_skip_sml.png);\n\theight:24px;\n\twidth:44px;\n\tfloat:left;\n}\n\n#ok:hover {\n\tbackground-image:url(.\/images\/windows\/button_ok_rollie.png);\n}\n\n#no:hover {\n\tbackground-image:url(.\/images\/windows\/button_no_sml_rollie.png);\n}\n\n#yes:hover {\n\tbackground-image:url(.\/images\/windows\/button_yes_sml_rollie.png);\n}\n\n#skip:hover {\n\tbackground-image:url(.\/images\/windows\/button_skip_sml_rollie.png);\n}\n\n#iphoneinfobutton {\n\tbackground-image:url(.\/images\/windows\/button_info.png);\n\theight:24px;\n\twidth:64px;\n\tfloat:left;\n}\n\n#iphoneinfobutton:hover {\n\tbackground-image:url(.\/images\/windows\/button_info_rolie.png);\n}\n\n#iphoneok {\n\tbackground-image:url(.\/images\/windows\/button_ok.png);\n\theight:24px;\n\twidth:64px;\n\tfloat:left;\n}\n\n#iphoneok:hover {\n\tbackground-image:url(.\/images\/windows\/button_ok_rollie.png);\n}\n\n#display_scroller {\n    position: absolute;\n    top: 10px;\n    bottom: 10px;\n    left: 226px;\n    width: 19px;\n\theight:85px;\n}\n#display_scrollarea {\n    position: absolute;\n    top: 10px;\n    bottom: 10px;\n    left: 100px;\n    right: 30px;\n}\n\n\n.scrollbar {\n\t-apple-dashboard-region: dashboard-region(control rectangle);\n}\n\n.scrollerThumb .barTop {\n\tbackground:url(.\/images\/scrollbar\/bartop.png) no-repeat;\n}\n\n.scrollerThumb .barMiddle {\n\tbackground:url('.\/images\/scrollbar\/barmid.png') repeat-y top left;\n}\n\n.scrollerThumb .barBottom {\n\tbackground:url(.\/images\/scrollbar\/barbottom.png) no-repeat;\n}\n\n.scrollerThumbActive .barTop {\t\n\tbackground:url(.\/images\/scrollbar\/bartop_down.png) no-repeat;\n}\n\n.scrollerThumbActive .barMiddle {\n\tbackground:url('.\/images\/scrollbar\/barmid_down.png') repeat-y top left;\n}\n\n.scrollerThumbActive .barBottom {\n\tbackground:url(.\/images\/scrollbar\/barbottom_down.png) no-repeat;\n}\n\/* @end *\/\n\n.pppconnect {\n\tposition:absolute;\n\tbackground-image:url(.\/images\/button_netconnect.png);\n\theight:12px;\n\twidth:116px;\n\t-apple-dashboard-region: dashboard-region(control rectangle);\n}\n\n.pppconnect:active {\n\tbackground-image:url(.\/images\/button_netconnect_down.png);\n}\n\n.pppdisconnect {\n\tposition:absolute;\n\tbackground-image:url(.\/images\/button_netdisconnect.png);\n\theight:12px;\n\twidth:116px;\n\t-apple-dashboard-region: dashboard-region(control rectangle);\n}\n\n.pppdisconnect:active {\n\tbackground-image:url(.\/images\/button_netdisconnect_down.png);\n}\n\n.pppdisconnectOverlay {\n\t-apple-dashboard-region: dashboard-region(control rectangle);\n\tbackground-image:url(.\/images\/button_networkeject.png);\n}\n\n.pppdisconnectOverlay:active {\n\tbackground-image:url(.\/images\/button_networkeject_down.png);\n}\n\n.diskicon {\n\t-apple-dashboard-region: dashboard-region(control rectangle);\n\topacity:1;\n}\n\n.diskicon:active {\n\topacity:0.5;\n}\n\n.resetBandwidth {\n\tbackground-image:url(.\/images\/back\/button_resetbandwidth.png);\n\twidth:212px;\n\theight:17px;\n\tposition:absolute;\n\ttop:105px;\n\tleft:22px;\n\tcursor:pointer;\n}\n\n.resetBandwidth:hover {\n\tbackground-image:url(.\/images\/back\/button_resetbandwidth_rolie.png);\n}"];

    function parseStylesheetSource(source) {
        if (!source) return;

        var css = source.replace(/\/\*[\s\S]*?\*\//g, "");
        var rulePattern = /([^{}]+)\{([^{}]*)\}/g;
        var match;

        while ((match = rulePattern.exec(css)) !== null) {
            var selectorText = match[1].trim();
            var body = match[2];
            var propertyMatch = body.match(/-apple-dashboard-region\s*:\s*([^;]+)/);

            if (selectorText && propertyMatch) {
                sourceRules.push({
                    selectorText: selectorText,
                    value: propertyMatch[1].trim()
                });
            }
        }
    }

    function loadStylesheetSources() {
        var styleElements = document.querySelectorAll("style");
        for (var i = 0; i < styleElements.length; i++) {
            parseStylesheetSource(styleElements[i].textContent || "");
        }

        var links = document.querySelectorAll('link[rel~="stylesheet"][href]');
        for (var j = 0; j < links.length; j++) {
            try {
                var stylesheetURL = new URL(links[j].href, document.baseURI);
                if (stylesheetURL.protocol !== "http:" && stylesheetURL.protocol !== "https:") {
                    continue;
                }

                fetch(stylesheetURL.href)
                    .then(function (response) {
                        return response.ok ? response.text() : "";
                    })
                    .then(parseStylesheetSource)
                    .catch(function () {});
            } catch (e) {}
        }
    }

    function dashboardRegionTextForElement(element) {
        var values = [];

        if (element.style && element.style.getPropertyValue) {
            var inlineValue = element.style.getPropertyValue("-apple-dashboard-region");
            if (inlineValue) values.push(inlineValue);
        }

        var inlineStyle = element.getAttribute("style") || "";
        var inlineMatch = inlineStyle.match(/-apple-dashboard-region\s*:\s*([^;]+)/);
        if (inlineMatch) values.push(inlineMatch[1].trim());

        try {
            var computedValue = window.getComputedStyle(element).getPropertyValue("-apple-dashboard-region");
            if (computedValue) values.push(computedValue);
        } catch (e) {}

        for (var i = 0; i < document.styleSheets.length; i++) {
            var sheet = document.styleSheets[i];
            var rules;
            try {
                rules = sheet.cssRules;
            } catch (e) {
                continue;
            }

            collectDashboardRegionRules(element, rules, values);
        }

        for (var j = 0; j < sourceRules.length; j++) {
            try {
                if (element.matches(sourceRules[j].selectorText)) {
                    values.push(sourceRules[j].value);
                }
            } catch (e) {}
        }

        return values.length ? values[values.length - 1] : "";
    }

    function collectDashboardRegionRules(element, rules, values) {
        for (var i = 0; i < rules.length; i++) {
            var rule = rules[i];

            if (rule.cssRules) {
                collectDashboardRegionRules(element, rule.cssRules, values);
                continue;
            }

            if (!rule.selectorText || !rule.style) continue;

            var value = rule.style.getPropertyValue("-apple-dashboard-region");
            if (!value) continue;

            try {
                if (element.matches(rule.selectorText)) values.push(value);
            } catch (e) {}
        }
    }

    function parseLength(value) {
        var parsed = parseFloat(value);
        if (!isFinite(parsed) || parsed < 0) return 0;
        return parsed;
    }

    function parseDashboardRegions(value) {
        if (!value || value === "none") return [];

        var regions = [];
        var pattern = /dashboard-region\(([^)]*)\)/g;
        var match;

        while ((match = pattern.exec(value)) !== null) {
            var parts = match[1].trim().split(/\s+/);
            if (parts.length < 2 || parts[0] !== "control") continue;

            var shape = parts[1];
            if (shape !== "rectangle" && shape !== "circle") continue;

            regions.push({
                shape: shape,
                top: parseLength(parts[2]),
                right: parseLength(parts[3]),
                bottom: parseLength(parts[4]),
                left: parseLength(parts[5])
            });
        }

        return regions;
    }

    function pointIsInRegion(clientX, clientY, element, region) {
        var rect = element.getBoundingClientRect();
        var left = rect.left + region.left;
        var top = rect.top + region.top;
        var right = rect.right - region.right;
        var bottom = rect.bottom - region.bottom;

        if (right < left || bottom < top) return false;

        if (region.shape === "rectangle") {
            return clientX >= left && clientX <= right && clientY >= top && clientY <= bottom;
        }

        var width = right - left;
        var height = bottom - top;
        var radius = Math.min(width, height) / 2;
        var centerX = left + width / 2;
        var centerY = top + height / 2;
        var dx = clientX - centerX;
        var dy = clientY - centerY;

        return dx * dx + dy * dy <= radius * radius;
    }

    function isInControlRegion(clientX, clientY) {
        var elements = document.elementsFromPoint(clientX, clientY);

        for (var i = 0; i < elements.length; i++) {
            var element = elements[i];
            var value = dashboardRegionTextForElement(element).trim();
            if (!value || value === "none") continue;

            var regions = parseDashboardRegions(value);
            for (var j = 0; j < regions.length; j++) {
                if (pointIsInRegion(clientX, clientY, element, regions[j])) return true;
            }
        }

        return false;
    }

    function isInteractiveTarget(target) {
        if (!target || target.nodeType !== 1) return false;

        var interactive = target.closest(
            'input, textarea, select, option, button, summary, [contenteditable=""], [contenteditable="true"], [role="slider"]'
        );

        if (!interactive) return false;
        return true;
    }

    function postDragMessage(name, payload) {
        try {
            window.webkit.messageHandlers[name].postMessage(payload || {});
        } catch (e) {}
    }

    function dashboardControlRegionsEnabled() {
        return window.__widgetPortingDashboardControlRegionsEnabled !== false;
    }

    document.addEventListener("mousedown", function (event) {
        if (!dashboardControlRegionsEnabled()) return;
        if (event.button !== 0) return;
        if (isInteractiveTarget(event.target)) return;
        if (isInControlRegion(event.clientX, event.clientY)) return;

        pendingDrag = {
            startX: event.clientX,
            startY: event.clientY
        };
        activeDrag = null;
    }, true);

    document.addEventListener("mousemove", function (event) {
        if (!dashboardControlRegionsEnabled()) return;
        if (!pendingDrag || (event.buttons & 1) !== 1) return;

        var dx = event.clientX - pendingDrag.startX;
        var dy = event.clientY - pendingDrag.startY;

        if (!activeDrag) {
            if (Math.abs(dx) < dragThreshold && Math.abs(dy) < dragThreshold) return;
            activeDrag = pendingDrag;
            postDragMessage("dashboardDragStart", {});
        }

        event.preventDefault();
        event.stopPropagation();
    }, true);

    document.addEventListener("mouseup", function (event) {
        if (!dashboardControlRegionsEnabled()) return;
        if (activeDrag) {
            postDragMessage("dashboardDragEnd", {});
            event.preventDefault();
            event.stopPropagation();
        }

        pendingDrag = null;
        activeDrag = null;
    }, true);

    window.addEventListener("blur", function () {
        if (activeDrag) {
            postDragMessage("dashboardDragEnd", {});
        }

        pendingDrag = null;
        activeDrag = null;
    });

    for (var i = 0; i < bundledStylesheetSources.length; i++) {
        parseStylesheetSource(bundledStylesheetSources[i]);
    }
    loadStylesheetSources();
})();
